describe('Login do usuário com sucesso', () => {
  it('Deve logar com sucesso', () => {

    cy.fazerLogin('testedesafio@email.com', 'abcd1234')

    cy.get('#tbay-topbar > div > div > div > ul > li:nth-child(1) > a > span')
    .should('have.text', 'Welcome testedesafio !')

    cy.wait(1000)

  })
})



describe('Erro - Usuário Inválido', () => {
  it('Não Deve logar com usuário inválido', () => {

    cy.fazerLogin('testedesafio@email', 'abcd1234')

    cy.contains('não está registrado neste site. Se você não está certo de seu nome de usuário, experimente o endereço de e-mail.')
        .should('be.visible')

    
    
    cy.wait(1000)

  })
})



describe('Erro - Senha Inválida', () => {
  it('Não Deve logar com senha inválida', () => {

    cy.fazerLogin('testedesafio@email.com', 'abcd')

    cy.contains(': A senha fornecida para o e-mail ')
        .should('be.visible')

    
    
    cy.wait(1000)

  })
})

